import requests
from bs4 import BeautifulSoup
import openpyxl

# Prompt the user to input their search query
your_query = input("Enter your search query: ")

# Construct the search URL with the user's query
url = f"https://en.wikinews.org/w/index.php?title=Special:Search&limit=20&offset=0&ns0=1&search={your_query}"

response = requests.get(url)
soup = BeautifulSoup(response.content, "html.parser")

# Find all the news article titles and links on the page
articles = soup.find_all("li", attrs="mw-search-result")

# Create a new Excel workbook and worksheet
workbook = openpyxl.Workbook()
worksheet = workbook.active
worksheet.title = "Search Results"

# Write the scraped data to the Excel worksheet
worksheet.cell(row=1, column=1, value="No.")
worksheet.cell(row=1, column=2, value="Title")
worksheet.cell(row=1, column=3, value="Date")
for i, article in enumerate(articles, start=2):
    title = article.find("div",attrs="mw-search-result-heading").text
    date = article.find("div", attrs="mw-search-result-data").text
    worksheet.cell(row=i, column=1, value=i-1)
    worksheet.cell(row=i, column=2, value=title)
    worksheet.cell(row=i, column=3, value=date)

# Save the Excel workbook
workbook.save(filename="Wikinews "+your_query+".xlsx")

print(f"Search results for '{your_query}' have been saved to Wikinews {your_query}.xlsx")